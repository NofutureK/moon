import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import mysql from "mysql2";

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MySQL 연결 설정
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "yourpassword",
  database: "board",
});

db.connect((err) => {
  if (err) {
    console.error("DB 연결 오류: ", err);
  } else {
    console.log("MySQL 연결 성공");
  }
});

// 게시물 목록 가져오기
app.get("/api/posts", (req, res) => {
  const sql = "SELECT * FROM posts";
  db.query(sql, (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.json(results);
    }
  });
});

// 게시물 추가하기
app.post("/api/posts", (req, res) => {
  const { title, content } = req.body;
  const sql = "INSERT INTO posts (title, content) VALUES (?, ?)";
  db.query(sql, [title, content], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.json({ id: result.insertId });
    }
  });
});

// 서버 시작
app.listen(5000, () => {
  console.log("백엔드 서버가 5000번 포트에서 실행 중입니다.");
});
