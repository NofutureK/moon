import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import HeaderComponent from "./component/Header";
import MainContent from "./component/MainContent";
import FooterContent from "./component/Footer";
import "./component/style.css";
import NoticePage from "./component/Notice";
import SlideCompent from "./component/Slide";
import FooterDown from "./component/FooterDown";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function App() {
  return (
    <Router>
      <div>
        <HeaderComponent />
        <Routes>
          <Route path="/" element={<MainContent />} />
          <Route path="/Notice" element={<NoticePage />} />
        </Routes>
        <FooterContent />
        <SlideCompent />
        <FooterDown />
      </div>
    </Router>
  );
}

export default App;
