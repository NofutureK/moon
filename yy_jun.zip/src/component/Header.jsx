import { Link } from "react-router-dom";
import "./style.css";
import "./Header.css";

const HeaderComponent = () => {
  return (
    <header className="main-background">
      <Link to={"/"} className="logo">
        <img src="/img/logo_nuri.png" alt="Logo" />
      </Link>
      <ul className="navi">
        <li className="submenu">
          <a href="#">고객지원</a>
          <ul>
            <li>
              <a href="#">문의하기</a>
            </li>
            <li>
              <a href="#">자주묻는질문</a>
            </li>
          </ul>
        </li>
        <li className="submenu">
          <a href="#">시안</a>
          <ul>
            <li>
              <a href="#">학회홈페이지</a>
            </li>
            <li>
              <a href="#">XML홈페이지</a>
            </li>
            <li>
              <a href="#">다국어사례</a>
            </li>
            <li>
              <a href="#">학술대회</a>
            </li>
            <li>
              <a href="#">저널레터</a>
            </li>
          </ul>
        </li>
        <li className="submenu">
          <a href="#">매뉴얼</a>
          <ul>
            <li>
              <a href="#">논문투고 매뉴얼</a>
            </li>
            <li>
              <a href="#">신규 홈페이지 매뉴얼</a>
            </li>
            <li>
              <a href="#">홈페이지 사용가능 폰트 안내</a>
            </li>
          </ul>
        </li>
        <li className="submenu">
          <a href="#">솔루션</a>
          <ul>
            <li>
              <a href="#">온라인논문투고시스템</a>
            </li>
            <li>
              <a href="#">학회 홈페이지</a>
            </li>
            <li>
              <a href="#">저널홈페이지/XML</a>
            </li>
            <li>
              <a href="#">뉴스레터/저널레터</a>
            </li>
            <li>
              <a href="#">편집디자인</a>
            </li>
          </ul>
        </li>
        <li className="submenu">
          <Link to="/Notice">공지사항</Link>
          <ul>
            <li>
              <a href="#">공지사항</a>
            </li>
            <li>
              <a href="#">개인정보처리방침</a>
            </li>
          </ul>
        </li>
      </ul>
      <hr />
    </header>
  );
};

export default HeaderComponent;
