import Slider from "react-slick";
import "./style.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useState } from "react";

const slides = [
  {
    img: "/img/Slideimg1.jpeg",
    text: "저널 홈페이지, Full text XML, Crossref",
    link: "/", // 링크 추가
  },
  {
    img: "/img/Slideimg2.jpeg",
    text: "온라인 논문투고 시스템 DBpiaONE",
    link: "/", // 링크 추가
  },
  {
    img: "/img/Slideimg3.jpeg",
    text: "학회 & 컨퍼런스 홈페이지",
    link: "/", // 링크 추가
  },
];

const SlideComponent = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    fade: true,
    beforeChange: (currentIndex, nextIndex) => setCurrentSlide(nextIndex),
  };

  return (
    <div className="slider-container">
      <Slider {...settings}>
        {slides.map((slide, index) => (
          <div key={index} className="slide-item">
            <div className="slide-content">
              <img
                src={slide.img}
                alt={`Slide ${index + 1}`}
                className="slide-image"
              />
              <a href={slide.link} className="slide-text">
                {slide.text}
              </a>
            </div>
          </div>
        ))}
      </Slider>
      <div className="current-slide">
        {`현재 슬라이드: ${currentSlide + 1}`}
      </div>
    </div>
  );
};

export default SlideComponent;
