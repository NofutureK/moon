import { useState, useEffect } from "react";
import "./style.css";

const initialNotices = [
  {
    id: 1,
    title: "누리미디어 개인정보처리방침 개정 안내",
    content:
      "회사는 원활한 서비스의 제공을 위하여 회원의 개인정보를 외부에 위탁하여 처리할 수 있습니다. 개인정보의 처리를 위탁하는 경우에는 미리 그 사실을 회원에게 고지하겠습니다.                개인정보 위탁처리업체 및 그 내용은 아래와 같습니다.",
    date: "2024-09-27",
  },
  {
    id: 2,
    title: "[온라인논문투고시스템] DBpiaONE 개선사항 안내",
    content:
      "동일한 심사위원이 재심을 요청하려면 삭제 후 다시 배정해야 하는 번거로움이 있었습니다심사완료한 심사위원은 이미지와 같이 '재배정' 버튼이 활성화 됩니다.",
    date: "2024-09-26",
  },
];

const NoticePage = () => {
  const [notices, setNotices] = useState(() => {
    const savedNotices = localStorage.getItem("notices");
    return savedNotices ? JSON.parse(savedNotices) : initialNotices;
  });
  const [visibleContentId, setVisibleContentId] = useState(null);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");

  useEffect(() => {
    localStorage.setItem("notices", JSON.stringify(notices));
  }, [notices]);

  const handleToggleContent = (id) => {
    setVisibleContentId((prevId) => (prevId === id ? null : id));
  };

  const handleAddNotice = () => {
    if (newTitle && newContent) {
      const newNotice = {
        id: notices.length + 1,
        title: newTitle,
        content: newContent,
        date: new Date().toLocaleDateString(),
      };
      setNotices((prevNotices) => [...prevNotices, newNotice]);
      setNewTitle("");
      setNewContent("");
    }
  };

  const handleDeleteNotice = (id) => {
    const updatedNotices = notices.filter((notice) => notice.id !== id);
    setNotices(updatedNotices);
  };

  return (
    <div>
      <h1 className="noticeh1">공지사항</h1>
      <ul style={{ listStyleType: "none", padding: 0 }}>
        {notices.map((notice) => (
          <li key={notice.id}>
            <h2
              onClick={() => handleToggleContent(notice.id)}
              style={{ cursor: "pointer" }}
            >
              {notice.title}
            </h2>
            {visibleContentId === notice.id && (
              <div>
                <p>{notice.content}</p>
                <small>{notice.date}</small>
                <button onClick={() => handleDeleteNotice(notice.id)}>
                  삭제
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>
      <h2>공지사항 추가</h2>
      <div className="input-container">
        <input
          type="text"
          placeholder="제목을 입력하세요"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          className="input-title"
        />
        <textarea
          placeholder="내용을 입력하세요"
          value={newContent}
          onChange={(e) => setNewContent(e.target.value)}
          className="input-content"
        />
        <button onClick={handleAddNotice} className="submit-button">
          글쓰기
        </button>
      </div>
    </div>
  );
};

export default NoticePage;
