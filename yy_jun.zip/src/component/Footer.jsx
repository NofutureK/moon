import React from "react";
import "./Footer.css";

const FooterContent = () => {
  return (
    <footer>
      <div className="footer-container">
        <div className="image-container">
          <img
            src="./img/manual_bg_1.png"
            alt="이미지 1"
            className="image-left"
          />
          <img
            src="./img/manual_icon_shaow.png"
            alt="이미지 2"
            className="image-right"
          />
        </div>
        <div className="text-container">
          <h1>학회 홈페이지 관리자용 간편 메뉴얼</h1>
          <h4 className="fh4">
            학회 홈페이지 관리자 이용 방법을 상세히 안내 드립니다. 팝업 게시,
            대량메일 발송 등 매뉴얼을 통해 보다 다양한 기능을 이용하실 수
            있습니다.
          </h4>
          <a href="#">
            <h3 className="fh3">간편 메뉴얼 바로보기=></h3>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default FooterContent;
