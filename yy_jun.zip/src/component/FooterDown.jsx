import "./FooterDown.css"; // FooterDown CSS 파일 임포트

const FooterDown = () => {
  return (
    <div className="footer-down">
      <div className="footer-images">
        <img
          src="/img/Book1.jpeg"
          alt="Footer Image 1"
          className="footer-image"
        />
        <img
          src="/img/Book2.jpeg"
          alt="Footer Image 2"
          className="footer-image"
        />
        <img
          src="/img/Book3.jpeg"
          alt="Footer Image 3"
          className="footer-image"
        />
        <img
          src="/img/Book4.jpeg"
          alt="Footer Image 4"
          className="footer-image"
        />
      </div>
      <div className="copyright">
        © {new Date().getFullYear()} Your Company Name. All rights reserved.
      </div>
    </div>
  );
};

export default FooterDown;
