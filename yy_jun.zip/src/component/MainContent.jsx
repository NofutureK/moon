// MainContent.js

import "./style.css";
import "./MainContent.css";
import icon1 from "./img/human.png";
import icon2 from "./img/file.png";
import icon3 from "./img/Book.png";
import icon4 from "./img/search.png";
import icon5 from "./img/moniter.png";

const MainContent = () => {
  return (
    <main className="main-background">
      <section className="text-section">
        <h1 className="main-text">Onestop Service Center</h1>
        <h4 className="main-subtext">
          "논문투고에서 온라인 출판까지" 학회를 위한 원스탑 토탈 솔루션
        </h4>
      </section>
      <section className="button">
        <ul>
          <li>
            <img src={icon1} alt="1:1 문의" className="icon" />
            <span className="text">1:1 문의</span>
          </li>
          <li>
            <img src={icon2} alt="솔루션 소개" className="icon" />
            <span className="text">솔루션 소개</span>
          </li>
          <li>
            <img src={icon3} alt="이용 매뉴얼" className="icon" />
            <span className="text">이용 매뉴얼</span>
          </li>
          <li>
            <img src={icon4} alt="FAQ" className="icon" />
            <span className="text">FAQ</span>
          </li>
          <li>
            <img src={icon5} alt="원격지원요청" className="icon" />
            <span className="text">원격지원요청</span>
          </li>
        </ul>
      </section>
    </main>
  );
};

export default MainContent;
